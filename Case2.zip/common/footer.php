<?php 

    echo '

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="./js/participants.js"></script>
    <script src="./js/index.js"></script>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- <div class="card">
      <div class="card-header">
        All rights reserved: 
      </div>
        <div class="card-body">
          <h5 class="card-title">Group 10 DICT ToT Batch 2</h5>
          <p class="card-text">Kenneth "POGI" Gamalo</p>
          <p class="card-text">Carlos Daniel</p>
          <p class="card-text">Jomar Ruiz</p>
          <p class="card-text">Rusty Cabacungan</p>
        </div>
      </div> -->

  </body>
</html>';

?>