<?php 

    $dbhost = 'ssql301.infinityfree.com';
    $dbusername = 'if0_35101269';
    $dbpassword = 'PoZiB26dTU';
    $dbname = 'if0_35101269_case2data';

 $connection = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

    // $dbhost = 'localhost';
    // $dbusername = 'root';
    // $dbpassword = '';
    // $dbname = 'act5';

    // $connection = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);
?>